# BUMX TOOL — Android Studio starter

Bản này là **mã nguồn dự án Android**, chưa phải APK/AAB đã build hoặc được Google Play duyệt.

## Mở và chạy
1. Giải nén ZIP, mở thư mục `BUMX-Android` bằng Android Studio bản hỗ trợ Android Gradle Plugin 8.9.1.
2. Cài Android SDK Platform 36 và JDK 17.
3. Build > Make Project, sau đó chạy trên thiết bị Android thật.
4. Mở app, cấp quyền hiển thị trên ứng dụng khác.
5. Vào Cài đặt > Trợ năng và bật BUMX.
6. Quay lại BUMX và khởi động menu nổi. Chọn điểm trên màn hình, sau đó dùng Auto Tap hoặc Auto Click.

## Chức năng trong bản khởi đầu
- Nút BUMX nổi có thể kéo thả.
- Menu Gaming Neon.
- Chọn tọa độ bằng thao tác chạm do người dùng chủ động.
- Auto Tap một lần; Auto Click lặp tại tọa độ đã chọn.
- Dừng tự động, chỉnh khoảng thời gian, lưu tọa độ/tốc độ bằng SharedPreferences.

## Trước khi phát hành Google Play
Đây là starter cần kiểm thử và hoàn thiện. Cần rà soát hành vi trên nhiều hãng máy, xử lý vòng đời/quyền, kiểm thử an toàn, thêm icon/ảnh chụp/chính sách quyền riêng tư, khai báo chính xác việc dùng Accessibility API và hoàn thành Play Console Data safety / Accessibility declaration. Google có thể từ chối ứng dụng nếu việc sử dụng Accessibility API không đáp ứng chính sách. Không quảng cáo đây là công cụ tăng FPS thật: chức năng Boost FPS chưa được triển khai.
