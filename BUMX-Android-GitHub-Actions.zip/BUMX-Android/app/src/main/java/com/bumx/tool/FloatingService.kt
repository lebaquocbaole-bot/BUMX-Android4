package com.bumx.tool

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.provider.Settings
import android.content.SharedPreferences
import kotlin.concurrent.thread
import java.util.concurrent.atomic.AtomicBoolean

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var prefs: SharedPreferences
    private var bubble: View? = null
    private var panel: View? = null
    private var targetX = 500f
    private var targetY = 800f
    private var interval = 500L
    private val running = AtomicBoolean(false)
    private var loopThread: Thread? = null
    private var mode = "CLICK"

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("bumx", Context.MODE_PRIVATE)
        targetX = prefs.getFloat("x", 500f); targetY = prefs.getFloat("y", 800f)
        interval = prefs.getLong("interval", 500L)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createChannel()
        val notification = if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, "bumx").setContentTitle("BUMX đang sẵn sàng")
                .setContentText("Menu nổi đang hoạt động").setSmallIcon(android.R.drawable.ic_media_play).build()
        else Notification.Builder(this).setContentTitle("BUMX").setSmallIcon(android.R.drawable.ic_media_play).build()
        startForeground(7, notification)
        showBubble()
    }
    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("bumx", "BUMX floating controls", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }
    private fun params(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h, if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
    )
    private fun neonBg() = GradientDrawable(GradientDrawable.Orientation.TL_BR,
        intArrayOf(0xFF160B35.toInt(), 0xFF071B38.toInt())).apply {
        cornerRadius = 28f; setStroke(2, 0xFF9B4DFF.toInt())
    }
    private fun text(s: String, size: Float = 15f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD; setPadding(12, 10, 12, 10)
    }
    private fun showBubble() {
        val v = TextView(this).apply {
            text = "BUMX"; textSize = 16f; gravity = Gravity.CENTER; setTextColor(Color.WHITE)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFF24105B.toInt()); setStroke(3, 0xFF00D9FF.toInt()) }
            setOnClickListener { if (panel == null) showPanel() else hidePanel() }
        }
        val p = params(76, 76).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 260 }
        v.setOnTouchListener(object : View.OnTouchListener {
            var sx=0f; var sy=0f; var ox=0; var oy=0; var moved=false
            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when(e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> { if (kotlin.math.abs(e.rawX-sx)>8 || kotlin.math.abs(e.rawY-sy)>8) moved=true
                        p.x=ox+(e.rawX-sx).toInt(); p.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(v,p); return true }
                    MotionEvent.ACTION_UP -> { if (!moved) v.performClick(); return true }
                }; return false
            }
        })
        bubble=v; wm.addView(v,p)
    }
    private fun hidePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel=null }
    private fun showPanel() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; background=neonBg(); setPadding(12,12,12,12) }
        root.addView(text("♛ BUMX TOOL", 22f))
        root.addView(text("AUTO CLICK  •  AUTO TAP"))
        val row1 = LinearLayout(this)
        row1.addView(Button(this).apply { text="CHỌN ĐIỂM"; setOnClickListener { hidePanel(); showTargetPicker() } }, LinearLayout.LayoutParams(0,-2,1f))
        row1.addView(Button(this).apply { text="AUTO CLICK"; setOnClickListener { mode="CLICK"; startLoop() } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row1)
        val row2 = LinearLayout(this)
        row2.addView(Button(this).apply { text="AUTO TAP"; setOnClickListener { mode="TAP"; stopLoop(); TapAccessibilityService.instance?.tap(targetX,targetY) ?: toast("Hãy bật BUMX trong Trợ năng") } }, LinearLayout.LayoutParams(0,-2,1f))
        row2.addView(Button(this).apply { text="DỪNG"; setOnClickListener { stopLoop() } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row2)
        root.addView(text("Tốc độ: ${interval} ms / lần"))
        val seek=SeekBar(this).apply { max=1970; progress=(2000-interval).toInt().coerceIn(30,1970) }
        seek.setOnSeekBarChangeListener(object: SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s:SeekBar?,v:Int,u:Boolean) { interval=(2000-v).coerceAtLeast(30).toLong() }
            override fun onStartTrackingTouch(s:SeekBar?) {}
            override fun onStopTrackingTouch(s:SeekBar?) { prefs.edit().putLong("interval",interval).apply() }
        })
        root.addView(seek)
        val row3=LinearLayout(this)
        row3.addView(Button(this).apply { text="LƯU CẤU HÌNH"; setOnClickListener { prefs.edit().putFloat("x",targetX).putFloat("y",targetY).putLong("interval",interval).apply(); toast("Đã lưu cấu hình") } }, LinearLayout.LayoutParams(0,-2,1f))
        row3.addView(Button(this).apply { text="ẨN MENU"; setOnClickListener { hidePanel() } }, LinearLayout.LayoutParams(0,-2,1f))
        root.addView(row3)
        panel=root
        val p=params(310,-2).apply { gravity=Gravity.CENTER }
        wm.addView(root,p)
    }
    private fun showTargetPicker() {
        val picker = FrameLayout(this).apply { setBackgroundColor(0x33000000); isClickable=true }
        picker.addView(text("CHẠM VÀO VỊ TRÍ MUỐN TỰ ĐỘNG NHẤN").apply {
            setBackgroundColor(0xCC160B35.toInt()); layoutParams=FrameLayout.LayoutParams(-1,-2,Gravity.TOP)
        })
        picker.setOnTouchListener { _,e ->
            if(e.action==MotionEvent.ACTION_UP) {
                targetX=e.rawX; targetY=e.rawY
                prefs.edit().putFloat("x",targetX).putFloat("y",targetY).apply()
                try { wm.removeView(picker) } catch (_:Exception) {}
                showPanel(); toast("Đã chọn tọa độ"); true
            } else true
        }
        wm.addView(picker, params(-1,-1).apply { flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN })
    }
    private fun startLoop() {
        val svc=TapAccessibilityService.instance
        if(svc==null) { toast("Hãy bật BUMX trong Cài đặt Trợ năng"); return }
        if(!running.compareAndSet(false,true)) return
        loopThread=thread(name="BUMX-AutoClick") {
            while(running.get()) {
                svc.tap(targetX,targetY)
                try { Thread.sleep(interval) } catch (_:InterruptedException) { break }
            }
        }
        toast("Đã bật Auto Click")
    }
    private fun stopLoop() { running.set(false); loopThread?.interrupt(); loopThread=null; toast("Đã dừng") }
    private fun toast(s:String) = android.widget.Toast.makeText(this,s,android.widget.Toast.LENGTH_SHORT).show()
    override fun onStartCommand(i:Intent?,f:Int,id:Int)=START_STICKY
    override fun onDestroy() { stopLoop(); hidePanel(); bubble?.let { try { wm.removeView(it) } catch (_:Exception) {} }; super.onDestroy() }
    override fun onBind(intent:Intent?):IBinder?=null
}
