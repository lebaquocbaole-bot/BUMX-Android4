package com.bumx.tool

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(0xFF09051B.toInt())
        }
        fun label(text: String, size: Float = 17f) = TextView(this).apply {
            this.text = text; textSize = size; setTextColor(0xFFE9E2FF.toInt())
            gravity = Gravity.CENTER; setPadding(8, 14, 8, 14)
        }
        fun button(text: String, action: () -> Unit) = Button(this).apply {
            this.text = text; setOnClickListener { action() }
        }
        layout.addView(label("✦ BUMX TOOL ✦", 30f))
        layout.addView(label("Gaming Neon • Floating Auto Tap"))
        layout.addView(label("1. Cấp quyền hiển thị trên ứng dụng khác.\n2. Bật dịch vụ BUMX trong Trợ năng.\n3. Quay lại đây và mở menu nổi.", 15f))
        layout.addView(button("CẤP QUYỀN MENU NỔI") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        layout.addView(button("MỞ CÀI ĐẶT TRỢ NĂNG") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        layout.addView(button("KHỞI ĐỘNG MENU BUMX") {
            if (Settings.canDrawOverlays(this)) startForegroundService(Intent(this, FloatingService::class.java))
            else startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        setContentView(layout)
    }
}
